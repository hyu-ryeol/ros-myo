var struct_l_o_g =
[
    [ "byID", "struct_l_o_g.html#a4c217adff0de2317e3de966c3c798785", null ],
    [ "fgSet", "struct_l_o_g.html#a52d31792c4d2dde07a9519e69d7c7714", null ]
];