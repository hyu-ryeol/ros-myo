var struct_i_byte =
[
    [ "byHigh", "struct_i_byte.html#a848840ef7f7bbb7ac5ce38d6684f44cb", null ],
    [ "byLow", "struct_i_byte.html#a88b2294b015ea60f05530e956cdd2604", null ]
];