var robot_8hpp =
[
    [ "TableOfRobotControlRegister", "struct_table_of_robot_control_register.html", "struct_table_of_robot_control_register" ],
    [ "MAX_DISP_DIFF", "robot_8hpp.html#a07f847900c1099e3ad97721f5c1d3f8d", null ],
    [ "MAX_SPEED_DIFF", "robot_8hpp.html#ac3bbb860100bd20505ac1ae83b241568", null ],
    [ "MY_PI", "robot_8hpp.html#acdf314019539248efc2b4f247a1b97ac", null ],
    [ "RPM2DPS", "robot_8hpp.html#ae42374c300b2a918e9089cc2cfd4a682", null ],
    [ "InitRobotParam", "robot_8hpp.html#a949b0dfb91143c10871c8d53b3455cad", null ],
    [ "MotData2RobotPosture", "robot_8hpp.html#a171a8967f051725e21bc993efe8a3950", null ],
    [ "MotPosi2RBPosi", "robot_8hpp.html#ac519fabdfab5b68245e2a30448446d3b", null ],
    [ "MotRPM2RBSpeed", "robot_8hpp.html#a195f3f5047a676921d6b6d71b2309aaa", null ],
    [ "RBAngRatio2RPM", "robot_8hpp.html#ac1a564561199897a410b9435cefac040", null ],
    [ "RBSpeed2MotRPM", "robot_8hpp.html#a36df0c57980b43ead5f8a225c82af2f5", null ],
    [ "ResetPosture", "robot_8hpp.html#a2fa949114d4c44792221af55b738467f", null ],
    [ "RobotCmd2MotCmd", "robot_8hpp.html#ace9e3998bba73ad7300326f289cfcda6", null ],
    [ "RB", "robot_8hpp.html#ab8627b1b966f412f806c4dbb43e67c02", null ]
];