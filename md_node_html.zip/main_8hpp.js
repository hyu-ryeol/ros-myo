var main_8hpp =
[
    [ "LOG", "struct_l_o_g.html", "struct_l_o_g" ],
    [ "Log", "main_8hpp.html#ac4cb286691a539f8d55b5912cdfbfa0c", null ]
];