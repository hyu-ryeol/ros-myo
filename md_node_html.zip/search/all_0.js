var searchData=
[
  ['_5fl_0',['_L',['../global_8hpp.html#a23b3808d12342e40e7459e77fccb85b6',1,'global.hpp']]],
  ['_5fr_1',['_R',['../global_8hpp.html#a828a8829107e3f2fa9a2fcc8d19e8c77',1,'global.hpp']]],
  ['_5ftheta_2',['_THETA',['../global_8hpp.html#a64902f36438cfc7f616070780c427d6c',1,'global.hpp']]],
  ['_5fx_3',['_X',['../global_8hpp.html#af67558313268d122af24803971b081d0',1,'global.hpp']]],
  ['_5fy_4',['_Y',['../global_8hpp.html#a54be7feb60963548285a11f13f4a8809',1,'global.hpp']]]
];
