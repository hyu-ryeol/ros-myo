var searchData=
[
  ['rbangratio2rpm_0',['RBAngRatio2RPM',['../robot_8hpp.html#ac1a564561199897a410b9435cefac040',1,'RBAngRatio2RPM(long lAngRatio):&#160;robot.cpp'],['../robot_8cpp.html#ac1a564561199897a410b9435cefac040',1,'RBAngRatio2RPM(long lAngRatio):&#160;robot.cpp']]],
  ['rbspeed2motrpm_1',['RBSpeed2MotRPM',['../robot_8hpp.html#a36df0c57980b43ead5f8a225c82af2f5',1,'RBSpeed2MotRPM(long lSpeed):&#160;robot.cpp'],['../robot_8cpp.html#a36df0c57980b43ead5f8a225c82af2f5',1,'RBSpeed2MotRPM(long lSpeed):&#160;robot.cpp']]],
  ['receivedatafromcontroller_2',['ReceiveDataFromController',['../com_8hpp.html#a3f8e0ddfe1fbc491f271b060577c800a',1,'ReceiveDataFromController(void):&#160;com.cpp'],['../com_8cpp.html#a3f8e0ddfe1fbc491f271b060577c800a',1,'ReceiveDataFromController(void):&#160;com.cpp']]],
  ['resetposture_3',['ResetPosture',['../robot_8hpp.html#a2fa949114d4c44792221af55b738467f',1,'ResetPosture(void):&#160;robot.cpp'],['../robot_8cpp.html#a2fa949114d4c44792221af55b738467f',1,'ResetPosture(void):&#160;robot.cpp']]],
  ['robotcmd2motcmd_4',['RobotCmd2MotCmd',['../robot_8hpp.html#ace9e3998bba73ad7300326f289cfcda6',1,'RobotCmd2MotCmd(int nRefSpeed, int nAngRatio):&#160;robot.cpp'],['../robot_8cpp.html#ace9e3998bba73ad7300326f289cfcda6',1,'RobotCmd2MotCmd(int nRefSpeed, int nAngRatio):&#160;robot.cpp']]]
];
