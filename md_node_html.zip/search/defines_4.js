var searchData=
[
  ['disable_0',['DISABLE',['../global_8hpp.html#a99496f7308834e8b220f7894efa0b6ab',1,'global.hpp']]],
  ['duration_1',['DURATION',['../com_8hpp.html#aa312b7c3e9d9981fb0d98cc4428f17bf',1,'com.hpp']]]
];
