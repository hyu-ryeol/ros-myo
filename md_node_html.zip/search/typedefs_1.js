var searchData=
[
  ['dword_0',['DWORD',['../global_8hpp.html#a798af1e30bc65f319c1a246cecf59e39',1,'global.hpp']]]
];
