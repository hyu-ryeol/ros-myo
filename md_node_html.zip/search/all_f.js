var searchData=
[
  ['r_0',['R',['../global_8hpp.html#a5c71a5e59a53413cd6c270266d63b031',1,'global.hpp']]],
  ['rb_1',['RB',['../robot_8hpp.html#ab8627b1b966f412f806c4dbb43e67c02',1,'RB():&#160;main.cpp'],['../main_8cpp.html#ab8627b1b966f412f806c4dbb43e67c02',1,'RB():&#160;main.cpp']]],
  ['rbangratio2rpm_2',['RBAngRatio2RPM',['../robot_8hpp.html#ac1a564561199897a410b9435cefac040',1,'RBAngRatio2RPM(long lAngRatio):&#160;robot.cpp'],['../robot_8cpp.html#ac1a564561199897a410b9435cefac040',1,'RBAngRatio2RPM(long lAngRatio):&#160;robot.cpp']]],
  ['rbspeed2motrpm_3',['RBSpeed2MotRPM',['../robot_8hpp.html#a36df0c57980b43ead5f8a225c82af2f5',1,'RBSpeed2MotRPM(long lSpeed):&#160;robot.cpp'],['../robot_8cpp.html#a36df0c57980b43ead5f8a225c82af2f5',1,'RBSpeed2MotRPM(long lSpeed):&#160;robot.cpp']]],
  ['receivedatafromcontroller_4',['ReceiveDataFromController',['../com_8hpp.html#a3f8e0ddfe1fbc491f271b060577c800a',1,'ReceiveDataFromController(void):&#160;com.cpp'],['../com_8cpp.html#a3f8e0ddfe1fbc491f271b060577c800a',1,'ReceiveDataFromController(void):&#160;com.cpp']]],
  ['request_5fpnt_5fmain_5fdata_5',['REQUEST_PNT_MAIN_DATA',['../com_8hpp.html#a33f13b96ac387d215ae8a02439afc244',1,'com.hpp']]],
  ['reset_6',['RESET',['../global_8hpp.html#ab702106cf3b3e96750b6845ded4e0299',1,'global.hpp']]],
  ['resetposture_7',['ResetPosture',['../robot_8hpp.html#a2fa949114d4c44792221af55b738467f',1,'ResetPosture(void):&#160;robot.cpp'],['../robot_8cpp.html#a2fa949114d4c44792221af55b738467f',1,'ResetPosture(void):&#160;robot.cpp']]],
  ['right_8',['RIGHT',['../cmd__main_8cpp.html#a80fb826a684cf3f0d306b22aa100ddac',1,'RIGHT():&#160;cmd_main.cpp'],['../global_8hpp.html#a80fb826a684cf3f0d306b22aa100ddac',1,'RIGHT():&#160;global.hpp']]],
  ['robot_2ecpp_9',['robot.cpp',['../robot_8cpp.html',1,'']]],
  ['robot_2ehpp_10',['robot.hpp',['../robot_8hpp.html',1,'']]],
  ['robotcmd2motcmd_11',['RobotCmd2MotCmd',['../robot_8hpp.html#ace9e3998bba73ad7300326f289cfcda6',1,'RobotCmd2MotCmd(int nRefSpeed, int nAngRatio):&#160;robot.cpp'],['../robot_8cpp.html#ace9e3998bba73ad7300326f289cfcda6',1,'RobotCmd2MotCmd(int nRefSpeed, int nAngRatio):&#160;robot.cpp']]],
  ['rpm2dps_12',['RPM2DPS',['../robot_8hpp.html#ae42374c300b2a918e9089cc2cfd4a682',1,'robot.hpp']]],
  ['rw_13',['RW',['../global_8hpp.html#afc4ded33ac0ca43defcce639e965748a',1,'global.hpp']]]
];
