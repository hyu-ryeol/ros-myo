var searchData=
[
  ['communication_0',['Communication',['../struct_communication.html',1,'']]]
];
