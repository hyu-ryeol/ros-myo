var searchData=
[
  ['byte2lint_0',['Byte2LInt',['../com_8hpp.html#ae3bae22a2f89d481a429920ee999eddb',1,'Byte2LInt(BYTE byData1, BYTE byData2, BYTE byData3, BYTE byData4):&#160;com.cpp'],['../com_8cpp.html#ae3bae22a2f89d481a429920ee999eddb',1,'Byte2LInt(BYTE byData1, BYTE byData2, BYTE byData3, BYTE byData4):&#160;com.cpp']]],
  ['byte2short_1',['Byte2Short',['../com_8hpp.html#a501a1f7adecb3dd8082d636a52ecca74',1,'Byte2Short(BYTE byLow, BYTE byHigh):&#160;com.cpp'],['../com_8cpp.html#a501a1f7adecb3dd8082d636a52ecca74',1,'Byte2Short(BYTE byLow, BYTE byHigh):&#160;com.cpp']]]
];
