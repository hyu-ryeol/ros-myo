var searchData=
[
  ['global_2ehpp_0',['global.hpp',['../global_8hpp.html',1,'']]]
];
