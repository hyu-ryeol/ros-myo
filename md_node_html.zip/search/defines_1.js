var searchData=
[
  ['abs_0',['Abs',['../global_8hpp.html#ae56b0282c58a65969c092e1eeeedd6f5',1,'global.hpp']]]
];
