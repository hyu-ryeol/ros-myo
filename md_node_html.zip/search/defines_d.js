var searchData=
[
  ['send_5fdata_5fafter_5f1s_0',['SEND_DATA_AFTER_1S',['../com_8hpp.html#a6484c7357abeaff05c11e7cbdef9da7d',1,'com.hpp']]],
  ['success_1',['SUCCESS',['../global_8hpp.html#aa90cac659d18e8ef6294c7ae337f6b58',1,'global.hpp']]]
];
