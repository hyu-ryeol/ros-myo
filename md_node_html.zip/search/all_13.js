var searchData=
[
  ['word_0',['WORD',['../global_8hpp.html#a197942eefa7db30960ae396d68339b97',1,'global.hpp']]]
];
