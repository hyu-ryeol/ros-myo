var searchData=
[
  ['log_0',['LOG',['../struct_l_o_g.html',1,'']]]
];
