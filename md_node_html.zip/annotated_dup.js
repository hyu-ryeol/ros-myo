var annotated_dup =
[
    [ "Communication", "struct_communication.html", "struct_communication" ],
    [ "IByte", "struct_i_byte.html", "struct_i_byte" ],
    [ "LOG", "struct_l_o_g.html", "struct_l_o_g" ],
    [ "MotorDriver", "struct_motor_driver.html", "struct_motor_driver" ],
    [ "TableOfRobotControlRegister", "struct_table_of_robot_control_register.html", "struct_table_of_robot_control_register" ]
];